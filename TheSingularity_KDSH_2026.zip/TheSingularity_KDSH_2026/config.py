"""
Configuration for Narrative Consistency Reasoning Engine.
Central place for all model names, paths, and hyperparameters.
"""

import torch
from typing import Dict, Any

# ==================== Device Configuration ====================
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
GPU_ENABLED = torch.cuda.is_available()

if GPU_ENABLED:
    print(f"[INFO] GPU detected: {torch.cuda.get_device_name(0)}")
    print(f"[INFO] CUDA Version: {torch.version.cuda}")
else:
    print("[WARNING] No GPU detected. Using CPU (slower inference)")

# ==================== Model Names ====================
MODELS = {
    "claim_extraction": "Qwen/Qwen2.5-3B-Instruct",  # For atomic claim decomposition
    "embedding": "sentence-transformers/all-MiniLM-L6-v2",  # For semantic retrieval
    "verification": "microsoft/deberta-v3-large",  # Large model for better accuracy
    "rationale_generation": "Qwen/Qwen2.5-3B-Instruct",  # For explanation generation
}

# ==================== Inference Parameters ====================
CLAIM_EXTRACTION_PARAMS = {
    "max_length": 1024,
    "temperature": 0.3,  # Low temperature for deterministic claims
    "top_p": 0.9,
}

VERIFIER_PARAMS = {
    "max_length": 512,
    "num_labels": 3,  # [ENTAILMENT, NEUTRAL, CONTRADICTION]
}

RATIONALE_PARAMS = {
    "max_length": 256,
    "temperature": 0.5,
}

# ==================== Narrative Chunking ====================
CHUNK_CONFIG = {
    "chunk_size": 800,  # tokens per chunk
    "chunk_overlap": 150,  # overlapping tokens
    "separator": "\n",  # primary separator
}

# ==================== Evidence Retrieval ====================
RETRIEVAL_CONFIG = {
    "top_k": 5,  # top-k relevant chunks per claim
    "similarity_threshold": 0.3,  # minimum similarity score
    "embedding_dim": 384,  # MiniLM-L6 output dimension
}

# ==================== Verification Scoring ====================
VERIFICATION_LABELS = {
    "ENTAILMENT": 1,  # Claim is supported
    "NEUTRAL": 0,  # No clear relationship
    "CONTRADICTION": -1,  # Claim contradicts narrative
}

# ==================== Consistency Decision Logic ====================
CONSISTENCY_CONFIG = {
    "contradiction_threshold": -1,  # If any claim <= this, label = 0 (inconsistent)
    "contradiction_only": True,  # Only contradictions matter (not neutral)
}

# ==================== Batch Processing ====================
BATCH_CONFIG = {
    "batch_size_embedding": 32,
    "batch_size_verification": 16,
    "num_workers": 4,  # For dataloader
}

# ==================== Pathway Pipeline ====================
PATHWAY_CONFIG = {
    "enable_pathway": True,  # Use Pathway for orchestration
    "checkpoint_dir": "./checkpoints",
    "cache_embeddings": True,
}

# ==================== Logging ====================
LOGGING_CONFIG = {
    "log_level": "INFO",
    "log_file": "./logs/consistency_engine.log",
}

def get_device() -> torch.device:
    """Get the appropriate device (GPU or CPU)."""
    return DEVICE

def is_gpu_available() -> bool:
    """Check if GPU is available and enabled."""
    return GPU_ENABLED

def get_all_config() -> Dict[str, Any]:
    """Get all configuration as a dictionary."""
    return {
        "device": str(DEVICE),
        "gpu_enabled": GPU_ENABLED,
        "models": MODELS,
        "claim_extraction": CLAIM_EXTRACTION_PARAMS,
        "verification": VERIFIER_PARAMS,
        "rationale": RATIONALE_PARAMS,
        "chunking": CHUNK_CONFIG,
        "retrieval": RETRIEVAL_CONFIG,
        "verification_labels": VERIFICATION_LABELS,
        "consistency": CONSISTENCY_CONFIG,
        "batch": BATCH_CONFIG,
        "pathway": PATHWAY_CONFIG,
    }
