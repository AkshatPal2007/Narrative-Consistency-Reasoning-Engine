"""
Evidence Retrieval Module.
Retrieves relevant narrative chunks for each claim using semantic similarity.
"""

import numpy as np
from typing import List, Dict, Tuple
from config import RETRIEVAL_CONFIG
from models.embedder import Embedder
from pipeline.pathway_index import PathwayChunkIndex, PATHWAY_AVAILABLE

class EvidenceRetriever:
    """
    Retrieves top-k most relevant narrative chunks for each claim.
    Uses semantic similarity with embedded claims and chunks.
    """
    
    def __init__(self, embedder: Embedder = None, use_pathway: bool = PATHWAY_AVAILABLE):
        """
        Initialize retriever with embedder and optional Pathway index.
        
        Args:
            embedder: Embedder instance. If None, creates new one.
            use_pathway: When True and Pathway is installed, store chunks/embeddings
                         in a Pathway table that acts as a doc store + vector index.
        """
        self.embedder = embedder or Embedder()
        self.top_k = RETRIEVAL_CONFIG["top_k"]
        self.similarity_threshold = RETRIEVAL_CONFIG["similarity_threshold"]

        # Cache for chunks (PathwayChunkIndex owns embeddings + retrieval)
        self.chunk_embeddings = None
        self.chunks = None
        self.use_pathway = use_pathway and PATHWAY_AVAILABLE
        self.pathway_index = PathwayChunkIndex(self.embedder, use_pathway=self.use_pathway)
    
    def index_chunks(self, chunks: List[str]):
        """
        Pre-compute and cache embeddings for narrative chunks.
        
        Args:
            chunks: List of narrative chunks to index
        """
        print(f"[INFO] Indexing {len(chunks)} narrative chunks...")
        self.chunks = chunks
        # Pathway-backed store (document store + vector index) with fallback
        try:
            self.pathway_index.ingest_chunks(chunks)
            # Mirror internal embeddings for stats/compatibility
            self.chunk_embeddings = self.pathway_index._np_embeddings
            self.use_pathway = self.pathway_index.use_pathway
        except Exception as exc:  # pragma: no cover - robustness for hackathon
            print(f"[WARNING] Pathway indexing failed, falling back to local retrieval: {exc}")
            self.use_pathway = False
            self.pathway_index.use_pathway = False
            self.chunk_embeddings = self.pathway_index._np_embeddings

        if self.chunk_embeddings is not None:
            print(f"[INFO] Chunk indexing complete. Embedding shape: {self.chunk_embeddings.shape}")
        else:
            print("[WARNING] Chunk embeddings unavailable after indexing.")
    
    def retrieve(self, claim: str, top_k: int = None) -> List[Dict]:
        """
        Retrieve top-k most relevant chunks for a claim.
        
        Args:
            claim: Factual claim to find evidence for
            top_k: Override default top_k value
            
        Returns:
            List of dicts with keys:
                - chunk: Narrative text
                - score: Similarity score (0-1)
                - rank: Position in results
        """
        if self.chunk_embeddings is None or self.chunks is None:
            raise RuntimeError("No chunks indexed. Call index_chunks() first.")
        
        top_k = top_k or self.top_k
        
        # All retrieval routes go through PathwayChunkIndex (Pathway or numpy fallback inside)
        results = self.pathway_index.retrieve_top_k(claim, top_k)

        # Apply similarity threshold to preserve legacy behavior
        filtered = [r for r in results if r["score"] >= self.similarity_threshold]
        return filtered
    
    def retrieve_batch(self, claims: List[str], top_k: int = None) -> Dict[str, List[Dict]]:
        """
        Retrieve evidence for multiple claims.
        
        Args:
            claims: List of claims
            top_k: Override default top_k value
            
        Returns:
            Dict mapping claim -> list of evidence dicts
        """
        if self.chunk_embeddings is None or self.chunks is None:
            raise RuntimeError("No chunks indexed. Call index_chunks() first.")
        
        top_k = top_k or self.top_k
        
        # PathwayChunkIndex handles retrieval; iterate per-claim to mirror legacy behavior
        results = {}
        for claim in claims:
            results[claim] = self.retrieve(claim, top_k=top_k)
        return results
    
    def get_statistics(self) -> Dict:
        """
        Get statistics about indexed chunks.
        
        Returns:
            Dict with statistics
        """
        if self.chunks is None:
            return {"status": "no chunks indexed"}
        
        chunk_lengths = [len(c.split()) for c in self.chunks]
        
        return {
            "total_chunks": len(self.chunks),
            "avg_chunk_length": np.mean(chunk_lengths),
            "min_chunk_length": np.min(chunk_lengths),
            "max_chunk_length": np.max(chunk_lengths),
            "embedding_shape": self.chunk_embeddings.shape if self.chunk_embeddings is not None else None,
        }
