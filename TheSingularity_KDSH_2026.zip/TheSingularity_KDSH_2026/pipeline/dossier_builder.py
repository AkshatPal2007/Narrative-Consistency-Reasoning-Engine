"""
Dossier Builder - Structured Evidence Linkage.
Generates academic-grade dossiers with explicit claim-excerpt pairs.

Enforces strict linking: Every claim must have verbatim excerpts with source attribution.
"""

import logging
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, asdict
import json

logger = logging.getLogger(__name__)


@dataclass
class ExcerptSource:
    """Source attribution for an excerpt."""
    book: str  # Novel name
    location_hint: str  # "Character says at beginning" / "After Chapter 5"
    char_start: int  # Character position in full text
    char_end: int  # Character position in full text
    excerpt_text: str  # Exact verbatim text from source


@dataclass
class ClaimEvidence:
    """Single claim with supporting/contradicting evidence."""
    claim_id: int
    claim_text: str  # Extracted atomic claim
    claim_type: str  # "character_trait", "event", "relationship", "backstory"
    evidence_excerpts: List[ExcerptSource]  # All supporting/contradicting excerpts
    verification_label: str  # "ENTAILMENT", "NEUTRAL", "CONTRADICTION"
    verification_score: float  # Confidence 0-1
    constraint_analysis: str  # Rigorous why/how analysis
    is_contradicted: bool  # Simple boolean for quick lookup
    subclaims: Optional[List[str]] = None  # Optional finer-grained sub-claims


@dataclass
class CharacterDossier:
    """Complete dossier for one character's consistency evaluation."""
    character_id: int
    character_name: str
    book: str
    
    backstory_text: str  # Full backstory provided
    all_claims: List[str]  # All extracted atomic claims
    
    claim_evidences: List[ClaimEvidence]  # Paired claims with evidence
    
    overall_consistency: int  # 1 = consistent, 0 = contradicted
    contradiction_count: int
    
    # Summary statistics
    total_claims: int
    verified_claims: int  # Claims with evidence found
    contradicted_claims: int
    supported_claims: int
    neutral_claims: int
    
    # Overall reasoning
    executive_summary: str  # 2-3 sentence summary of consistency decision


class DossierBuilder:
    """
    Builds structured academic dossiers with explicit linkage.
    
    Core principle: Every claim must be traceable to source text.
    Every conclusion must cite specific evidence.
    """
    
    def __init__(self):
        self.source_books = {}  # Cache of full book texts
        self.claim_counter = 0
        
    def load_source_texts(self, book_paths: Dict[str, str]):
        """Load full texts for source attribution.
        
        Args:
            book_paths: {"book_name": "/path/to/file.txt"}
        """
        for book_name, path in book_paths.items():
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    self.source_books[book_name] = f.read()
                logger.info(f"✓ Loaded {book_name} ({len(self.source_books[book_name]):,} chars)")
            except Exception as e:
                logger.error(f"✗ Failed to load {book_name}: {e}")
    
    def build_dossier(
        self,
        character_id: int,
        character_name: str,
        book: str,
        backstory: str,
        claims: List[str],
        verifications: List[Dict],  # From consistency engine
        overall_consistency: int,
        contradiction_count: int,
    ) -> CharacterDossier:
        """Build complete dossier with explicit linkage.
        
        Args:
            character_id: ID of character
            character_name: Character name
            book: Novel name
            backstory: Full backstory text
            claims: All extracted claims
            verifications: Verification results from engine
            overall_consistency: 1 or 0
            contradiction_count: Number of contradictions found
            
        Returns:
            Structured dossier with explicit claim-evidence pairs
        """
        
        # Build claim-evidence pairs
        claim_evidences = []
        supported_count = 0
        contradicted_count = 0
        neutral_count = 0
        
        for i, claim in enumerate(claims):
            # Find corresponding verification
            verification = next((v for v in verifications if v.get('claim') == claim), None)
            
            if not verification:
                logger.warning(f"No verification found for claim: {claim[:50]}...")
                continue
            
            # Extract evidence excerpt with source attribution
            excerpt_source = self._get_source_attribution(
                book=book,
                evidence_text=verification.get('evidence', ''),
                claim=claim,
            )

            # Sub-claims (simple heuristic split)
            subclaims = self._extract_subclaims(claim)
            
            # Generate constraint analysis
            constraint_analysis = self._analyze_constraint(
                claim=claim,
                evidence=verification.get('evidence', ''),
                label=verification.get('label', 'NEUTRAL'),
                score=verification.get('score', 0),
            )
            
            # Create claim evidence pair
            is_contradicted = verification.get('label') == 'CONTRADICTION'
            
            claim_evidence = ClaimEvidence(
                claim_id=i,
                claim_text=claim,
                claim_type=self._classify_claim(claim),
                subclaims=subclaims,
                evidence_excerpts=[excerpt_source] if excerpt_source else [],
                verification_label=verification.get('label', 'NEUTRAL'),
                verification_score=verification.get('score', 0),
                constraint_analysis=constraint_analysis,
                is_contradicted=is_contradicted,
            )
            
            claim_evidences.append(claim_evidence)
            
            # Update counters
            if is_contradicted:
                contradicted_count += 1
            elif verification.get('label') == 'ENTAILMENT':
                supported_count += 1
            else:
                neutral_count += 1
        
        # Generate executive summary
        executive_summary = self._generate_executive_summary(
            character_name=character_name,
            total_claims=len(claims),
            contradicted=contradicted_count,
            supported=supported_count,
            overall_consistency=overall_consistency,
        )
        
        # Build dossier
        dossier = CharacterDossier(
            character_id=character_id,
            character_name=character_name,
            book=book,
            backstory_text=backstory,
            all_claims=claims,
            claim_evidences=claim_evidences,
            overall_consistency=overall_consistency,
            contradiction_count=contradiction_count,
            total_claims=len(claims),
            verified_claims=len([c for c in claim_evidences if c.evidence_excerpts]),
            contradicted_claims=contradicted_count,
            supported_claims=supported_count,
            neutral_claims=neutral_count,
            executive_summary=executive_summary,
        )
        
        return dossier
    
    def _get_source_attribution(
        self,
        book: str,
        evidence_text: str,
        claim: str,
    ) -> Optional[ExcerptSource]:
        """Extract source attribution for evidence.
        
        Finds exact location of evidence in source text.
        """
        if not evidence_text or book not in self.source_books:
            return None
        
        source_text = self.source_books[book]
        
        # Try to find exact match in source
        if evidence_text in source_text:
            char_start = source_text.find(evidence_text)
            char_end = char_start + len(evidence_text)
            
            # Generate location hint
            location_hint = self._get_location_hint(source_text, char_start)
            
            return ExcerptSource(
                book=book,
                location_hint=location_hint,
                char_start=char_start,
                char_end=char_end,
                excerpt_text=evidence_text[:300],  # Limit excerpt length
            )
        
        # If no exact match, try substring match (evidence might be chunked/processed)
        for i in range(len(evidence_text) - 50, min(len(evidence_text), 200), 10):
            substring = evidence_text[:i]
            if substring in source_text:
                char_start = source_text.find(substring)
                char_end = char_start + len(substring)
                location_hint = self._get_location_hint(source_text, char_start)
                
                return ExcerptSource(
                    book=book,
                    location_hint=location_hint,
                    char_start=char_start,
                    char_end=char_end,
                    excerpt_text=substring,
                )
        
        return None
    
    def _get_location_hint(self, source_text: str, char_pos: int) -> str:
        """Generate human-readable location hint for character position."""
        # Simple approach: count lines and paragraphs
        text_before = source_text[:char_pos]
        line_num = text_before.count('\n') + 1
        para_num = text_before.count('\n\n') + 1
        
        # Find surrounding context
        start = max(0, char_pos - 100)
        end = min(len(source_text), char_pos + 100)
        context = source_text[start:end].strip()
        context = context[:80] + "..." if len(context) > 80 else context
        
        return f"Line ~{line_num}, Para ~{para_num} | Context: '{context}'"
    
    def _classify_claim(self, claim: str) -> str:
        """Classify the type of claim (simple heuristic)."""
        claim_lower = claim.lower()
        
        if any(x in claim_lower for x in ['was', 'is', 'were', 'trait', 'personality']):
            return "character_trait"
        elif any(x in claim_lower for x in ['happened', 'occurred', 'did', 'action']):
            return "event"
        elif any(x in claim_lower for x in ['father', 'mother', 'child', 'son', 'daughter', 'brother', 'sister', 'married']):
            return "relationship"
        else:
            return "backstory"

    def _extract_subclaims(self, claim: str) -> List[str]:
        """Lightweight sub-claim extraction for novelty and clarity.

        Splits long claims on common delimiters to expose finer-grained pieces.
        Keeps only meaningful fragments to avoid noise.
        """
        delimiters = [";", " and ", " but ", " however "]
        parts = [claim]
        for d in delimiters:
            parts = [p for piece in parts for p in piece.split(d)]
        subclaims = [p.strip() for p in parts if len(p.strip()) > 12]
        return subclaims
    
    def _analyze_constraint(
        self,
        claim: str,
        evidence: str,
        label: str,
        score: float,
    ) -> str:
        """Generate rigorous constraint analysis.
        
        Explains WHY the relationship holds (not just THAT it holds).
        """
        if label == "CONTRADICTION":
            analysis = (
                f"CONSTRAINT VIOLATED: The claim states '{claim[:100]}...' "
                f"However, the narrative indicates: '{evidence[:100]}...'. "
                f"This represents a direct logical contradiction. "
                f"The backstory presupposes a state that the narrative explicitly contradicts. "
                f"Confidence: {score:.2f}"
            )
        elif label == "ENTAILMENT":
            analysis = (
                f"CLAIM SUPPORTED: The claim '{claim[:100]}...' "
                f"is directly supported by narrative evidence: '{evidence[:100]}...'. "
                f"This textual evidence confirms the backstory assertion. "
                f"Confidence: {score:.2f}"
            )
        else:  # NEUTRAL
            analysis = (
                f"INSUFFICIENT EVIDENCE: The claim '{claim[:100]}...' "
                f"is not directly addressed by available narrative evidence. "
                f"While the text mentions '{evidence[:100]}...', "
                f"it does not provide sufficient basis for verification. "
                f"Confidence: {score:.2f}"
            )
        
        return analysis
    
    def _generate_executive_summary(
        self,
        character_name: str,
        total_claims: int,
        contradicted: int,
        supported: int,
        overall_consistency: int,
    ) -> str:
        """Generate executive summary of consistency decision."""
        if overall_consistency == 1:
            summary = (
                f"{character_name}'s backstory is CONSISTENT with the narrative. "
                f"Of {total_claims} claims extracted, {supported} are supported and {contradicted} "
                f"are contradicted. The backstory elements are logically aligned with the narrative."
            )
        else:
            summary = (
                f"{character_name}'s backstory is INCONSISTENT with the narrative. "
                f"Of {total_claims} claims, {contradicted} significant contradictions were identified. "
                f"The backstory contains elements that directly conflict with established narrative facts."
            )
        
        return summary
    
    def dossier_to_dict(self, dossier: CharacterDossier) -> Dict:
        """Convert dossier to dictionary for JSON serialization."""
        return {
            "character_id": int(dossier.character_id),
            "character_name": dossier.character_name,
            "book": dossier.book,
            "backstory": dossier.backstory_text[:500],  # Truncate for storage
            "overall_consistency": int(dossier.overall_consistency),
            "executive_summary": dossier.executive_summary,
            "statistics": {
                "total_claims": int(dossier.total_claims),
                "verified_claims": int(dossier.verified_claims),
                "contradicted_claims": int(dossier.contradicted_claims),
                "supported_claims": int(dossier.supported_claims),
                "neutral_claims": int(dossier.neutral_claims),
            },
            "claim_evidence_pairs": [
                {
                    "claim_id": int(ce.claim_id),
                    "claim_text": ce.claim_text,
                    "claim_type": ce.claim_type,
                    "subclaims": ce.subclaims,
                    "verification": {
                        "label": ce.verification_label,
                        "score": float(ce.verification_score),
                        "is_contradicted": ce.is_contradicted,
                    },
                    "evidence": {
                        "excerpt": ce.evidence_excerpts[0].excerpt_text if ce.evidence_excerpts else "",
                        "source": ce.evidence_excerpts[0].location_hint if ce.evidence_excerpts else "",
                        "book": ce.evidence_excerpts[0].book if ce.evidence_excerpts else "",
                    } if ce.evidence_excerpts else None,
                    "constraint_analysis": ce.constraint_analysis,
                }
                for ce in dossier.claim_evidences
            ],
        }
    
    def dossier_to_csv_row(self, dossier: CharacterDossier, idx: int) -> Dict:
        """Convert dossier to CSV-compatible row.
        
        Creates compact row with key evidence linkage.
        """
        # Find strongest contradiction (if any)
        contradictions = [ce for ce in dossier.claim_evidences if ce.is_contradicted]
        
        if contradictions:
            strongest = contradictions[0]
            primary_claim = strongest.claim_text[:100]
            primary_evidence = strongest.evidence_excerpts[0].excerpt_text[:100] if strongest.evidence_excerpts else ""
            primary_analysis = strongest.constraint_analysis[:200]
        else:
            primary_claim = dossier.all_claims[0][:100] if dossier.all_claims else ""
            primary_evidence = ""
            primary_analysis = dossier.executive_summary[:200]
        
        return {
            "id": dossier.character_id,
            "character": dossier.character_name,
            "book": dossier.book,
            "prediction": dossier.overall_consistency,
            "confidence": 1.0 if dossier.overall_consistency == 1 else 0.5 + (0.1 * max(0, 3 - dossier.contradiction_count)),
            "primary_claim": primary_claim,
            "evidence_excerpt": primary_evidence,
            "constraint_analysis": primary_analysis,
            "rationale": dossier.executive_summary,
        }
