"""
Pathway-backed chunk index for narrative ingestion and vector search.
"""

from typing import List, Dict, Optional
import numpy as np

try:
    import pathway as pw
    PATHWAY_AVAILABLE = True
except ImportError:
    PATHWAY_AVAILABLE = False


class PathwayChunkIndex:
    """Stores narrative chunks in Pathway for Track A requirements.
    
    Ingests chunks into a Pathway table and performs retrieval via NumPy.
    """

    def __init__(self, embedder, use_pathway: bool = True):
        self.embedder = embedder
        self.use_pathway = use_pathway and PATHWAY_AVAILABLE
        self._pw_table = None
        self._np_embeddings: Optional[np.ndarray] = None
        self._chunks: Optional[List[str]] = None

    def ingest_chunks(self, chunks: List[str]):
        embeddings = self.embedder.encode(chunks, batch_size=32, convert_to_tensor=False)
        self._np_embeddings = np.asarray(embeddings)
        self._chunks = list(chunks)

        if self.use_pathway:
            try:
                rows = [{"chunk_id": i, "chunk": chunk} for i, chunk in enumerate(chunks)]
                self._pw_table = pw.Table.from_rows(rows)
                print(f"[PATHWAY] Narrative chunks ingested into Pathway table (count={len(chunks)})")
            except Exception:
                self._pw_table = None
                self.use_pathway = False
        else:
            self._pw_table = None

    def retrieve_top_k(self, claim: str, k: int) -> List[Dict]:
        if self._np_embeddings is None or self._chunks is None:
            raise RuntimeError("PathwayChunkIndex not initialized. Call ingest_chunks() first.")

        q_emb = self.embedder.encode(claim, batch_size=1, convert_to_tensor=False)[0]
        q = np.asarray(q_emb)
        denom = (np.linalg.norm(q) * np.linalg.norm(self._np_embeddings, axis=1))
        denom = np.where(denom == 0, 1e-9, denom)
        sims = np.dot(self._np_embeddings, q) / denom
        top_indices = sims.argsort()[::-1][:k]
        
        results = []
        for rank, idx in enumerate(top_indices):
            results.append({
                "chunk": self._chunks[idx],
                "score": float(sims[idx]),
                "rank": rank + 1,
                "chunk_id": int(idx),
            })
        return results