"""
Text Chunking Module.
Splits long narratives into overlapping chunks for efficient processing.
"""

from typing import List, Tuple
from config import CHUNK_CONFIG

class NarrativeChunker:
    """
    Splits narrative text into overlapping chunks.
    Designed to preserve context while enabling parallel processing.
    """
    
    def __init__(
        self,
        chunk_size: int = CHUNK_CONFIG["chunk_size"],
        overlap: int = CHUNK_CONFIG["chunk_overlap"],
    ):
        """
        Initialize chunker with token-based chunking.
        
        Args:
            chunk_size: Tokens per chunk
            overlap: Overlapping tokens between chunks
        """
        self.chunk_size = chunk_size
        self.overlap = overlap
        
        # Simple word-to-token approximation
        self.tokens_per_word = 1.3  # Average for English
        self.chars_per_token = 4.0  # Average characters per token
    
    def chunk(self, text: str) -> List[str]:
        """
        Split text into overlapping chunks.
        
        Args:
            text: Narrative text
            
        Returns:
            List of overlapping chunks
        """
        # Estimate token count
        estimated_tokens = len(text) / self.chars_per_token
        
        if estimated_tokens <= self.chunk_size:
            # Text is small, return as single chunk
            return [text]
        
        # Convert token sizes to character sizes for splitting
        chunk_chars = int(self.chunk_size * self.chars_per_token)
        overlap_chars = int(self.overlap * self.chars_per_token)
        
        chunks = []
        start = 0
        
        while start < len(text):
            end = min(start + chunk_chars, len(text))
            chunk = text[start:end]
            chunks.append(chunk.strip())
            
            # Move start position forward (accounting for overlap)
            start += chunk_chars - overlap_chars
        
        print(f"[DEBUG] Split narrative into {len(chunks)} chunks")
        return chunks
    
    def chunk_with_info(self, text: str) -> List[Tuple[str, int, int]]:
        """
        Split text into chunks with position information.
        
        Args:
            text: Narrative text
            
        Returns:
            List of (chunk, start_pos, end_pos) tuples
        """
        chunks = self.chunk(text)
        chunks_with_info = []
        
        current_pos = 0
        for chunk in chunks:
            start_pos = text.find(chunk, current_pos)
            end_pos = start_pos + len(chunk)
            chunks_with_info.append((chunk, start_pos, end_pos))
            current_pos = end_pos
        
        return chunks_with_info
    
    @staticmethod
    def estimate_tokens(text: str) -> int:
        """
        Estimate token count for text (approximate).
        Useful for pre-flight checks.
        
        Args:
            text: Text to estimate
            
        Returns:
            Approximate token count
        """
        # Simple heuristic: divide characters by average token length
        return int(len(text) / 4.0)
