"""
Pipeline module initialization.

from pipeline.consistency_engine import NarrativeConsistencyEngine, ConsistencyResult
from pipeline.dossier_builder import DossierBuilder, CharacterDossier, ClaimEvidence
from pipeline.dossier_utils import load_source_books, generate_structured_output

__all__ = [
	'NarrativeConsistencyEngine',
	'ConsistencyResult',
	'DossierBuilder',
	'CharacterDossier',
	'ClaimEvidence',
	'load_source_books',
	'generate_structured_output',
]
"""
