"""
Consistency Engine - Main Pipeline Orchestration.
Implements the complete narrative consistency reasoning pipeline using Pathway.
"""

import logging
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
import json

# Pathway for distributed computing (optional, can run standalone)
try:
    import pathway as pw
    PATHWAY_AVAILABLE = True
except ImportError:
    PATHWAY_AVAILABLE = False
    print("[WARNING] Pathway not installed. Running in standalone mode.")

from config import (
    CONSISTENCY_CONFIG,
    VERIFICATION_LABELS,
    get_device,
    is_gpu_available,
)
from models.claim_extractor import ClaimExtractor
from models.embedder import Embedder
from models.verifier import Verifier
from models.rationale_generator import RationaleGenerator
from pipeline.chunker import NarrativeChunker
from pipeline.retriever import EvidenceRetriever
from pipeline.dossier_builder import DossierBuilder

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class ConsistencyResult:
    """Result of consistency verification."""
    
    consistency_label: int  # 0 = inconsistent, 1 = consistent
    rationale: Optional[str] = None
    claims: Optional[List[str]] = None
    verifications: Optional[List[Dict]] = None
    strongest_contradiction: Optional[Tuple] = None
    num_contradictions: int = 0
    processing_time: float = 0.0


class NarrativeConsistencyEngine:
    """
    End-to-end pipeline for narrative consistency reasoning.
    
    Pipeline:
    1. Extract atomic claims from backstory (Qwen)
    2. Split narrative into overlapping chunks
    3. Embed claims and chunks (MiniLM)
    4. Retrieve relevant evidence for each claim
    5. Verify each claim against evidence (DeBERTa)
    6. Aggregate results and determine consistency
    7. Generate rationale for explanation
    """
    
    def __init__(self, enable_rationale: bool = True):
        """
        Initialize all pipeline components.
        
        Args:
            enable_rationale: Generate explanations (lazy-loaded to save VRAM)
        """
        self.enable_rationale = enable_rationale
        self._rationale_generator = None  # Lazy-loaded on first use
        logger.debug(f"GPU Available: {is_gpu_available()}")
        
        # Initialize core models (rationale skipped to save VRAM on 8GB GPUs)
        self.claim_extractor = ClaimExtractor()
        self.embedder = Embedder()
        self.verifier = Verifier()
        
        # Initialize pipeline components
        self.chunker = NarrativeChunker()
        # Enable Pathway usage in retrieval (with built-in fallback when unavailable)
        self.retriever = EvidenceRetriever(self.embedder, use_pathway=True)
        self.dossier_builder = DossierBuilder()
    
    @property
    def rationale_generator(self):
        """Lazy-load rationale generator to save VRAM (only when needed)."""
        if self._rationale_generator is None and self.enable_rationale:
            logger.info("[LAZY-LOAD] Loading rationale generator on first use...")
            self._rationale_generator = RationaleGenerator()
        return self._rationale_generator
    
    def verify(
        self,
        backstory: str,
        narrative: str,
        generate_rationale: bool = True,
    ) -> ConsistencyResult:
        """
        Main entry point for consistency verification.
        
        Args:
            backstory: Character backstory text
            narrative: Long narrative text
            generate_rationale: Generate explanation (overrides enable_rationale if False)
            
        Returns:
            ConsistencyResult with label, rationale, and details
        """
        import time
        start_time = time.time()
        
        try:
            # Pipeline execution (6 steps)
            claims = self._extract_claims(backstory)
            chunks = self._chunk_narrative(narrative)
            self.retriever.index_chunks(chunks)
            evidence_dict = self._retrieve_evidence(claims)
            verifications = self._verify_claims(claims, evidence_dict)
            consistency_label, strongest_contradiction, num_contradictions = \
                self._aggregate_results(verifications)
            
            # Step 6: Generate rationale (optional)
            rationale = None
            if self.enable_rationale and generate_rationale:
                # Store final decision for rationale alignment
                self._last_consistency_label = consistency_label
                rationale = self._generate_rationale(
                    backstory,
                    strongest_contradiction,
                    num_contradictions,
                )
                logger.info(f"  ✓ Rationale generated")
            
            elapsed_time = time.time() - start_time
            logger.info(f"Total processing time: {elapsed_time:.2f}s")
            logger.info("=" * 60)
            
            # Build result
            result = ConsistencyResult(
                consistency_label=consistency_label,
                rationale=rationale,
                claims=claims,
                verifications=verifications,
                strongest_contradiction=strongest_contradiction,
                num_contradictions=num_contradictions,
                processing_time=elapsed_time,
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Pipeline error: {str(e)}")
            raise
    
    def build_structured_dossier(
        self,
        character_id: int,
        character_name: str,
        book: str,
        backstory: str,
        narrative: str,
        source_book_paths: Optional[Dict[str, str]] = None,
    ) -> Tuple[Dict, Any]:
        """
        Build structured academic dossier with explicit claim-excerpt pairs.
    
        Args:
            character_id: Character ID
            character_name: Character name
            book: Novel name
            backstory: Character backstory
            narrative: Novel narrative
            source_book_paths: Paths to primary text files for exact attribution
        
        Returns:
            Dictionary with structured dossier
        """
        logger.info(f"Building structured dossier for {character_name}...")
    
        # Load source texts for attribution
        if source_book_paths:
            self.dossier_builder.load_source_texts(source_book_paths)
    
        # Run verification
        result = self.verify(backstory, narrative, generate_rationale=False)
    
        # Build dossier with explicit linkage
        dossier = self.dossier_builder.build_dossier(
            character_id=character_id,
            character_name=character_name,
            book=book,
            backstory=backstory,
            claims=result.claims or [],
            verifications=result.verifications or [],
            overall_consistency=result.consistency_label,
            contradiction_count=result.num_contradictions,
        )
    
        # Convert to dictionary format
        dossier_dict = self.dossier_builder.dossier_to_dict(dossier)
    
        logger.info(f"✓ Dossier built: {dossier.total_claims} claims, "
                   f"{dossier.contradicted_claims} contradicted")
    
        return dossier_dict, dossier

    def verify_with_structured_output(
        self,
        character_id: int,
        character_name: str,
        book: str,
        backstory: str,
        narrative: str,
        source_book_paths: Optional[Dict[str, str]] = None,
    ) -> Tuple[Dict, Dict]:
        """Convenience helper: run verification and return CSV-ready row.

        Returns:
            dossier_dict: Structured dossier dictionary
            csv_row: Compact row with explicit claim-excerpt-analysis fields
        """
        dossier_dict, dossier = self.build_structured_dossier(
            character_id=character_id,
            character_name=character_name,
            book=book,
            backstory=backstory,
            narrative=narrative,
            source_book_paths=source_book_paths,
        )

        csv_row = self.dossier_builder.dossier_to_csv_row(dossier, character_id)
        return dossier_dict, csv_row
    
    def _extract_claims(self, backstory: str) -> List[str]:
        """Step 1: Extract atomic claims."""
        claims = self.claim_extractor.extract_claims(backstory)
        return claims
    
    def _chunk_narrative(self, narrative: str) -> List[str]:
        """Step 2: Chunk narrative."""
        chunks = self.chunker.chunk(narrative)
        return chunks
    
    def _retrieve_evidence(self, claims: List[str]) -> Dict[str, List[Dict]]:
        """Step 3: Retrieve evidence for claims."""
        evidence_dict = self.retriever.retrieve_batch(claims)
        return evidence_dict
    
    def _verify_claims(
        self,
        claims: List[str],
        evidence_dict: Dict[str, List[Dict]],
    ) -> List[Dict]:
        """Step 4: Verify each claim against evidence."""
        verifications = []
        
        for claim in claims:
            evidence_list = evidence_dict.get(claim, [])
            
            if not evidence_list:
                logger.warning(f"  ⚠ No evidence found for claim: {claim[:50]}...")
                continue
            top_evidence = evidence_list[0]["chunk"]
            
            # Verify
            result = self.verifier.verify(claim, top_evidence)
            
            verification = {
                "claim": claim,
                "evidence": top_evidence,
                "evidence_rank": evidence_list[0]["rank"],
                "evidence_score": evidence_list[0]["score"],
                "label": result["label"],
                "score": result["score"],
                "numerical_score": self.verifier.get_score(result["label"]),
            }
            
            verifications.append(verification)
        
        return verifications
    
    def _aggregate_results(
        self,
        verifications: List[Dict],
    ) -> Tuple[int, Optional[Tuple], int]:
        """
        Step 5: Aggregate verification results.
        
        New logic (Track A requirements):
        - Only strong contradictions count.
        - contradiction_ratio = strong_contradictions / total_verified_claims.
        - Inconsistent if ratio >= 0.3.
        - Strong contradiction: label == "CONTRADICTION" and numerical_score <= -0.6.
        Returns:
            (consistency_label, strongest_contradiction, num_strong_contradictions)
        """
        if not verifications:
            return 1, None, 0  # No claims = consistent by default

        total_claims = len(verifications)

        # Identify contradictions with confidence threshold
        contradictions = [
            v for v in verifications
            if v["label"] == "CONTRADICTION" and v.get("score", 0) >= 0.5
        ]
        num_contradictions = len(contradictions)

        # Balanced decision logic:
        # - If ≥40% are contradictions → inconsistent
        # - If ≥3 contradictions → inconsistent (even if <40%)
        contradiction_ratio = num_contradictions / total_claims
        consistency_label = 0 if (contradiction_ratio >= 0.4 or num_contradictions >= 3) else 1

        # Track strongest contradiction
        strongest_contradiction = None
        if contradictions:
            strongest = max(
                contradictions,
                key=lambda x: x.get("score", 0),
            )
            strongest_contradiction = (
                strongest["claim"],
                strongest["evidence"],
                strongest.get("score", 0),
            )

        return consistency_label, strongest_contradiction, num_contradictions
    
    def _generate_rationale(
        self,
        backstory: str,
        strongest_contradiction: Optional[Tuple],
        num_contradictions: int,
    ) -> str:
        """Step 6: Generate rationale."""
        backstory_summary = backstory[:100] + "..." if len(backstory) > 100 else backstory
        # Default label to consistent if unavailable
        label = getattr(self, "_last_consistency_label", 1)

        # Guard if rationale generator is disabled
        if not self.rationale_generator:
            if label == 1:
                if num_contradictions > 0:
                    return (
                        "Overall CONSISTENT: Minor or isolated contradictions were detected "
                        f"({num_contradictions}), but the preponderance of evidence supports the backstory."
                    )
                return "Overall CONSISTENT: Verified claims align with the narrative with no contradictions."
            else:
                if strongest_contradiction:
                    claim, evidence, _ = strongest_contradiction
                    return (
                        "Overall INCONSISTENT: The backstory conflicts with narrative evidence. "
                        f"Example — Claim: '{claim[:100]}...' vs Evidence: '{evidence[:100]}...'."
                    )
                return "Overall INCONSISTENT: Multiple contradictions outweigh supporting evidence."

        # Use generator with label-aligned prompting
        if label == 1:
            # Consistent final decision: never produce inconsistent rationale
            return self.rationale_generator.generate_consistency_decision_rationale(
                backstory_summary,
                strongest_contradiction=None,
                num_contradictions=num_contradictions,
            )
        else:
            # Inconsistent final decision
            if strongest_contradiction:
                claim, evidence, score = strongest_contradiction
                return self.rationale_generator.generate_consistency_decision_rationale(
                    backstory_summary,
                    strongest_contradiction=(claim[:100] + "...", evidence[:100] + "...", score),
                    num_contradictions=num_contradictions,
                )
            # No single strongest contradiction available, still inconsistent
            return self.rationale_generator.generate_consistency_decision_rationale(
                backstory_summary,
                strongest_contradiction=("Multiple contradictions", "Across several narrative segments", 0.0),
                num_contradictions=num_contradictions,
            )
    
    def get_pipeline_status(self) -> Dict:
        """Get current pipeline status and model info."""
        status = {
            "gpu_available": is_gpu_available(),
            "device": str(get_device()),
            "models": {
                "claim_extractor": f"{self.claim_extractor.model_name} - GPU: {self.claim_extractor.is_on_gpu}",
                "embedding": f"{self.embedder.model_name}",
                "verifier": f"{self.verifier.model_name} - GPU: {self.verifier.is_on_gpu}",
                "rationale_generator": f"{self.rationale_generator.model_name if self.rationale_generator else 'disabled'} - GPU: {self.rationale_generator.is_on_gpu if self.rationale_generator else False}",
            },
            "pathway_available": PATHWAY_AVAILABLE,
        }
        return status


def run_consistency_check(
    backstory: str,
    narrative: str,
    engine: Optional[NarrativeConsistencyEngine] = None,
) -> Dict:
    """
    Convenience function to run consistency check.
    
    Args:
        backstory: Character backstory
        narrative: Long narrative
        engine: Existing engine or creates new
        
    Returns:
        Dict with consistency_label and rationale
    """
    if engine is None:
        engine = NarrativeConsistencyEngine()
    
    result = engine.verify(backstory, narrative)
    
    return {
        "consistency_label": result.consistency_label,
        "rationale": result.rationale,
        "num_contradictions": result.num_contradictions,
        "processing_time": result.processing_time,
    }
