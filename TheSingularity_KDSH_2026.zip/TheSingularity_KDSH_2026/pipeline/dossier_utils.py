"""
Integration utilities for dossier building with existing pipeline.
Provides helper functions to load source texts and generate structured output.
"""

import os
from typing import Dict, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


def load_source_books(dataset_dir: str = "./Dataset") -> Dict[str, str]:
    """Load all source book texts from dataset directory.
    
    Args:
        dataset_dir: Path to Dataset folder containing Books/ subfolder
        
    Returns:
        Dictionary mapping book names to file paths
    """
    books_dir = os.path.join(dataset_dir, "Books")
    book_paths = {}
    
    if not os.path.exists(books_dir):
        logger.warning(f"Books directory not found at {books_dir}")
        return book_paths
    
    for filename in os.listdir(books_dir):
        if filename.endswith('.txt'):
            filepath = os.path.join(books_dir, filename)
            # Book name is filename without extension, normalized
            book_name = filename.replace('.txt', '')
            book_paths[book_name] = filepath
            logger.info(f"Found source text: {book_name}")
    
    return book_paths


def generate_structured_output(
    dossier_dict: Dict,
    engine,
    character_id: int,
    sample: Dict,
) -> Dict:
    """Generate complete structured output with all required fields.
    
    Args:
        dossier_dict: Output from dossier builder
        engine: NarrativeConsistencyEngine instance
        character_id: Character ID
        sample: Original sample data
        
    Returns:
        Structured output row ready for CSV or JSON
    """
    
    dossier = dossier_dict
    
    # Extract key information
    overall_consistency = dossier['overall_consistency']
    confidence = dossier.get('confidence', 1.0 if overall_consistency == 1 else 0.5)
    
    # Find strongest contradiction if inconsistent
    strongest_claim = ""
    strongest_excerpt = ""
    strongest_analysis = ""
    
    if dossier['claim_evidence_pairs']:
        # Get first contradicted or most relevant claim
        contradicted = [c for c in dossier['claim_evidence_pairs'] if c['verification']['is_contradicted']]
        if contradicted:
            c = contradicted[0]
            strongest_claim = c['claim_text']
            strongest_excerpt = c['evidence']['excerpt'] if c['evidence'] else ""
            strongest_analysis = c['constraint_analysis']
        else:
            # Use first claim
            c = dossier['claim_evidence_pairs'][0]
            strongest_claim = c['claim_text']
            strongest_excerpt = c['evidence']['excerpt'] if c['evidence'] else ""
            strongest_analysis = c['constraint_analysis']
    
    return {
        # Core output (Track A requirements)
        'id': character_id,
        'character': sample.get('character', ''),
        'book': sample.get('book', ''),
        'prediction': overall_consistency,  # Binary 1/0
        'confidence': confidence,
        
        # Structured evidence (Priority 1 requirements)
        'claim': strongest_claim,
        'excerpt': strongest_excerpt,
        'analysis': strongest_analysis,
        'rationale': dossier['executive_summary'],
        
        # Statistics
        'total_claims': dossier['statistics']['total_claims'],
        'contradicted_claims': dossier['statistics']['contradicted_claims'],
        'supported_claims': dossier['statistics']['supported_claims'],
    }
