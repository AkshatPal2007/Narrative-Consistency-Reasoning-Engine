"""
Model initialization and management utilities.
Base class for all model wrappers.
"""

import torch
from typing import Optional
from config import get_device, is_gpu_available

class BaseModel:
    """
    Base class for all model wrappers.
    Handles device management and common operations.
    """
    
    def __init__(self, model_name: str, model_type: str):
        """
        Initialize model on appropriate device.
        
        Args:
            model_name: HuggingFace model identifier
            model_type: Type of model (e.g., 'embedding', 'classification')
        """
        self.model_name = model_name
        self.model_type = model_type
        self.device = get_device()
        self.model = None
        self.tokenizer = None
        print(f"[INFO] Initializing {model_type} model: {model_name}")
        print(f"[INFO] Device: {self.device}")
    
    def to_device(self):
        """Move model to appropriate device."""
        if self.model is not None:
            self.model = self.model.to(self.device)
            if torch.cuda.is_available():
                self.model = self.model.half()  # FP16 for faster inference
                print(f"[DEBUG] Enabled FP16 precision on GPU")
    
    def set_eval_mode(self):
        """Set model to evaluation mode and disable gradients."""
        if self.model is not None:
            self.model.eval()
            torch.set_grad_enabled(False)
    
    @property
    def is_on_gpu(self) -> bool:
        """Check if model is on GPU."""
        if self.model is None:
            return False
        return next(self.model.parameters()).is_cuda
