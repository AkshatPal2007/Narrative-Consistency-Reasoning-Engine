"""
Claim Extraction Module.
Decomposes backstory into atomic factual claims using Qwen.
"""

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from typing import List
from config import MODELS, CLAIM_EXTRACTION_PARAMS, get_device
from . import BaseModel

class ClaimExtractor(BaseModel):
    """
    Extracts atomic factual claims from backstory text.
    Uses Qwen2.5-3B Instruct for instruction-following capability.
    """
    
    def __init__(self):
        """Initialize claim extraction model."""
        super().__init__(MODELS["claim_extraction"], "claim_extraction")
        self._load_model()
        self.to_device()
        self.set_eval_mode()
    
    def _load_model(self):
        """Load Qwen model and tokenizer with optimizations."""
        print(f"[INFO] Loading Qwen model...")
        self.tokenizer = AutoTokenizer.from_pretrained(
            MODELS["claim_extraction"],
            trust_remote_code=True,
            padding_side="left",
        )
        
        # Load with device_map for automatic GPU distribution
        self.model = AutoModelForCausalLM.from_pretrained(
            MODELS["claim_extraction"],
            trust_remote_code=True,
            torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
            device_map="auto" if torch.cuda.is_available() else None,
        )
        print(f"[INFO] Qwen model loaded successfully")
    
    def extract_claims(self, backstory: str) -> List[str]:
        """
        Extract atomic claims from backstory.
        
        Args:
            backstory: Character backstory text
            
        Returns:
            List of atomic factual claims
        """
        prompt = self._create_extraction_prompt(backstory)
        
        # Tokenize
        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=2048,
        ).to(self.device)
        
        # Generate claims
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=CLAIM_EXTRACTION_PARAMS["max_length"],
                temperature=CLAIM_EXTRACTION_PARAMS["temperature"],
                top_p=CLAIM_EXTRACTION_PARAMS["top_p"],
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id,
            )
        
        # Decode and parse
        response = self.tokenizer.decode(
            outputs[0],
            skip_special_tokens=True,
            clean_up_tokenization_spaces=True,
        )
        
        claims = self._parse_claims(response)
        return claims
    
    def _create_extraction_prompt(self, backstory: str) -> str:
        """Create instruction prompt for claim extraction."""
        prompt = f"""Extract atomic factual claims from the following character backstory. 
Each claim should be a single, independent statement that can be verified against a narrative.
Format each claim on a new line starting with "- ".

Backstory:
{backstory}

Atomic Claims:
"""
        return prompt
    
    def _parse_claims(self, response: str) -> List[str]:
        """
        Parse claims from model response.
        
        Args:
            response: Raw model output
            
        Returns:
            List of cleaned claims
        """
        lines = response.split("\n")
        claims = []
        
        # Extract lines starting with "- "
        for line in lines:
            line = line.strip()
            if line.startswith("- "):
                claim = line[2:].strip()
                if claim and len(claim) > 5:  # Filter out very short lines
                    claims.append(claim)
        
        if not claims:
            # Fallback: treat each sentence as a claim
            sentences = backstory.split(". ")
            claims = [s.strip() + "." for s in sentences if s.strip()]
        
        print(f"[DEBUG] Extracted {len(claims)} claims from backstory")
        return claims
