"""
Verification Module.
Classifies claim-evidence pairs using Natural Language Inference (NLI).
Uses DeBERTa v3 for high-quality MNLI classification.
"""

import torch
import numpy as np
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from typing import Dict, List, Tuple
from config import MODELS, VERIFIER_PARAMS, VERIFICATION_LABELS, get_device
from . import BaseModel

class Verifier(BaseModel):
    """
    Verifies claims against evidence using NLI.
    Classifies each claim-evidence pair as ENTAILMENT, NEUTRAL, or CONTRADICTION.
    """
    
    # Label mapping for DeBERTa-v3 MNLI (standard format)
    LABEL_MAP = {
        0: "CONTRADICTION",  # Premise contradicts hypothesis
        1: "NEUTRAL",        # No clear relationship
        2: "ENTAILMENT",     # Premise entails hypothesis
    }
    
    def __init__(self):
        """Initialize verification model."""
        super().__init__(MODELS["verification"], "verification")
        self._load_model()
        self.to_device()
        self.set_eval_mode()
    
    def _load_model(self):
        """Load DeBERTa model and tokenizer."""
        print(f"[INFO] Loading DeBERTa verification model...")
        self.tokenizer = AutoTokenizer.from_pretrained(
            MODELS["verification"],
            trust_remote_code=True,
        )
        
        self.model = AutoModelForSequenceClassification.from_pretrained(
            MODELS["verification"],
            trust_remote_code=True,
            torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
            device_map=None,  # avoid auto sharding for models without _no_split_modules
        )
        print(f"[INFO] DeBERTa model loaded successfully")
    
    def verify(
        self,
        claim: str,
        evidence: str,
    ) -> Dict[str, any]:
        """
        Verify if claim is supported by evidence.
        
        Args:
            claim: Factual claim (hypothesis)
            evidence: Narrative evidence (premise)
            
        Returns:
            Dict with:
                - label: ENTAILMENT, NEUTRAL, or CONTRADICTION
                - score: Confidence (0-1)
                - logits: Raw model outputs
        """
        # Tokenize as NLI format: (premise, hypothesis)
        inputs = self.tokenizer(
            evidence,  # Premise
            claim,     # Hypothesis
            truncation=True,
            max_length=VERIFIER_PARAMS["max_length"],
            return_tensors="pt",
        ).to(self.device)
        
        # Get predictions
        with torch.no_grad():
            outputs = self.model(**inputs)
        
        logits = outputs.logits[0]
        probs = torch.softmax(logits, dim=-1)
        
        # Get predicted label
        predicted_label_id = torch.argmax(logits, dim=-1).item()
        predicted_label = self.LABEL_MAP[predicted_label_id]
        predicted_score = probs[predicted_label_id].item()
        
        result = {
            "label": predicted_label,
            "score": predicted_score,
            "logits": logits.cpu().numpy(),
            "probs": probs.cpu().numpy(),
        }
        
        return result
    
    def verify_batch(
        self,
        claims: List[str],
        evidence_list: List[str],
        batch_size: int = 16,
    ) -> List[Dict]:
        """
        Verify multiple claim-evidence pairs in batches.
        
        Args:
            claims: List of claims
            evidence_list: List of evidence texts (same length as claims)
            batch_size: Batch size for processing
            
        Returns:
            List of verification results
        """
        assert len(claims) == len(evidence_list), "Claims and evidence must have same length"
        
        results = []
        
        # Process in batches
        for i in range(0, len(claims), batch_size):
            batch_claims = claims[i:i+batch_size]
            batch_evidence = evidence_list[i:i+batch_size]
            
            # Tokenize batch
            inputs = self.tokenizer(
                batch_evidence,
                batch_claims,
                truncation=True,
                max_length=VERIFIER_PARAMS["max_length"],
                return_tensors="pt",
                padding=True,
            ).to(self.device)
            
            # Get predictions
            with torch.no_grad():
                outputs = self.model(**inputs)
            
            logits = outputs.logits
            probs = torch.softmax(logits, dim=-1)
            predicted_labels = torch.argmax(logits, dim=-1)
            
            # Parse results
            for j, (claim, evidence) in enumerate(zip(batch_claims, batch_evidence)):
                label_id = predicted_labels[j].item()
                label = self.LABEL_MAP[label_id]
                score = probs[j, label_id].item()
                
                result = {
                    "claim": claim,
                    "evidence": evidence,
                    "label": label,
                    "score": score,
                    "logits": logits[j].cpu().numpy(),
                }
                results.append(result)
        
        return results
    
    def get_score(self, label: str) -> int:
        """
        Convert label to numerical score for consistency calculation.
        
        Args:
            label: ENTAILMENT, NEUTRAL, or CONTRADICTION
            
        Returns:
            Numerical score (1, 0, or -1)
        """
        return VERIFICATION_LABELS.get(label, 0)
