"""
Rationale Generation Module.
Generates human-readable explanations for consistency decisions.
Uses Qwen for instruction-following generation.
"""

import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from typing import Optional
from config import MODELS, RATIONALE_PARAMS, get_device
from . import BaseModel

class RationaleGenerator(BaseModel):
    """
    Generates concise, human-readable rationales for consistency decisions.
    Used to explain contradictions or provide evidence summaries.
    """
    
    def __init__(self):
        """Initialize rationale generation model."""
        super().__init__(MODELS["rationale_generation"], "rationale_generation")
        self._load_model()
        self.to_device()
        self.set_eval_mode()
    
    def _load_model(self):
        """Load Qwen model and tokenizer."""
        print(f"[INFO] Loading Qwen rationale generation model...")
        self.tokenizer = AutoTokenizer.from_pretrained(
            MODELS["rationale_generation"],
            trust_remote_code=True,
            padding_side="left",
        )
        
        self.model = AutoModelForCausalLM.from_pretrained(
            MODELS["rationale_generation"],
            trust_remote_code=True,
            torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
            device_map="auto" if torch.cuda.is_available() else None,
        )
        print(f"[INFO] Qwen rationale model loaded successfully")
    
    def generate_contradiction_rationale(
        self,
        claim: str,
        evidence: str,
    ) -> str:
        """
        Generate explanation for a contradiction.
        
        Args:
            claim: Conflicting claim
            evidence: Contradicting evidence
            
        Returns:
            Short human-readable rationale
        """
        prompt = f"""Explain in one sentence why this claim contradicts the narrative evidence.

Claim: {claim}

Evidence: {evidence}

Explanation:
"""
        return self._generate(prompt)
    
    def generate_verification_summary(
        self,
        claim: str,
        verification_label: str,
        evidence: str,
    ) -> str:
        """
        Generate summary of verification result.
        
        Args:
            claim: Verified claim
            verification_label: ENTAILMENT, NEUTRAL, or CONTRADICTION
            evidence: Supporting/contradicting evidence
            
        Returns:
            Short summary
        """
        prompt = f"""Briefly summarize the relationship between this claim and evidence.

Claim: {claim}

Relationship: {verification_label}

Evidence: {evidence}

Summary:
"""
        return self._generate(prompt)
    
    def generate_consistency_decision_rationale(
        self,
        backstory_summary: str,
        strongest_contradiction: Optional[tuple] = None,
        num_contradictions: int = 0,
    ) -> str:
        """
        Generate overall rationale for consistency decision.
        
        Args:
            backstory_summary: Brief summary of backstory
            strongest_contradiction: (claim, evidence, score) tuple
            num_contradictions: Total number of contradictions found
            
        Returns:
            Overall explanation
        """
        if strongest_contradiction is None:
            # Consistent final decision; acknowledge minor contradictions if present
            if num_contradictions > 0:
                prompt = f"""The following backstory is CONSISTENT with the narrative.

Backstory: {backstory_summary}

Note: Minor or isolated contradictions were detected ({num_contradictions}), but overall evidence supports consistency.

Reasoning:
"""
            else:
                prompt = f"""The following backstory is CONSISTENT with the narrative.

Backstory: {backstory_summary}

Reasoning:
"""
        else:
            claim, evidence, score = strongest_contradiction
            prompt = f"""The following backstory is INCONSISTENT with the narrative.

Backstory: {backstory_summary}

Strongest Contradiction:
- Claim: {claim}
- Evidence: {evidence}

Explain why this is inconsistent:
"""
        
        return self._generate(prompt)
    
    def _generate(self, prompt: str) -> str:
        """
        Generate text from prompt.
        
        Args:
            prompt: Input prompt
            
        Returns:
            Generated text
        """
        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=1024,
        ).to(self.device)
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=150,
                temperature=0.0,
                do_sample=False,
                pad_token_id=self.tokenizer.eos_token_id,
            )
        
        response = self.tokenizer.decode(
            outputs[0],
            skip_special_tokens=True,
            clean_up_tokenization_spaces=True,
        )
        
        # Extract only the generated part (remove prompt)
        generated = response[len(prompt):].strip()
        
        # Truncate to first sentence if too long
        sentences = generated.split(". ")
        if len(sentences) > 2:
            generated = ". ".join(sentences[:2]) + "."
        
        return generated[:250]  # Limit to 250 chars
