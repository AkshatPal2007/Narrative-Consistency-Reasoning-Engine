"""
Embedding Module.
Creates semantic embeddings for claims and narrative chunks.
Uses all-MiniLM-L6-v2 for efficient semantic similarity.
"""

import torch
import numpy as np
from typing import List, Union
from sentence_transformers import SentenceTransformer
from config import MODELS, RETRIEVAL_CONFIG, get_device
from . import BaseModel

class Embedder(BaseModel):
    """
    Encodes text into semantic embeddings.
    Optimized for GPU inference with batching.
    """
    
    def __init__(self):
        """Initialize embedding model."""
        super().__init__(MODELS["embedding"], "embedding")
        self._load_model()
    
    def _load_model(self):
        """Load SentenceTransformer model with GPU support."""
        print(f"[INFO] Loading embedding model...")
        self.model = SentenceTransformer(
            MODELS["embedding"],
            device=str(get_device()),
        )
        
        # Verify embedding dimension
        test_embedding = self.model.encode("test")
        expected_dim = RETRIEVAL_CONFIG["embedding_dim"]
        actual_dim = len(test_embedding)
        
        if actual_dim != expected_dim:
            print(f"[WARNING] Expected embedding dim {expected_dim}, got {actual_dim}")
        
        print(f"[INFO] Embedding model loaded. Dimension: {actual_dim}")
    
    def encode(
        self,
        texts: Union[str, List[str]],
        batch_size: int = 32,
        convert_to_tensor: bool = False,
    ) -> Union[np.ndarray, torch.Tensor]:
        """
        Encode text(s) into embeddings.
        
        Args:
            texts: Single text or list of texts
            batch_size: Batch size for encoding
            convert_to_tensor: Return as torch tensor if True
            
        Returns:
            Embeddings as numpy array or torch tensor
        """
        # Handle single string
        if isinstance(texts, str):
            texts = [texts]
        
        # Encode with batching
        embeddings = self.model.encode(
            texts,
            batch_size=batch_size,
            convert_to_tensor=convert_to_tensor,
            show_progress_bar=False,
        )
        
        return embeddings
    
    def similarity(
        self,
        embeddings1: Union[np.ndarray, torch.Tensor],
        embeddings2: Union[np.ndarray, torch.Tensor],
    ) -> np.ndarray:
        """
        Compute cosine similarity between two sets of embeddings.
        
        Args:
            embeddings1: Shape (n, d)
            embeddings2: Shape (m, d)
            
        Returns:
            Similarity matrix of shape (n, m)
        """
        # Normalize embeddings
        if isinstance(embeddings1, torch.Tensor):
            embeddings1 = embeddings1.cpu().numpy()
        if isinstance(embeddings2, torch.Tensor):
            embeddings2 = embeddings2.cpu().numpy()
        
        embeddings1_norm = embeddings1 / (np.linalg.norm(embeddings1, axis=1, keepdims=True) + 1e-8)
        embeddings2_norm = embeddings2 / (np.linalg.norm(embeddings2, axis=1, keepdims=True) + 1e-8)
        
        # Compute cosine similarity
        similarity_matrix = np.dot(embeddings1_norm, embeddings2_norm.T)
        
        return similarity_matrix
    
    def retrieve_top_k(
        self,
        query_embedding: Union[np.ndarray, torch.Tensor],
        corpus_embeddings: Union[np.ndarray, torch.Tensor],
        k: int = 5,
    ) -> tuple:
        """
        Retrieve top-k most similar embeddings from corpus.
        
        Args:
            query_embedding: Single embedding (1, d)
            corpus_embeddings: Corpus embeddings (n, d)
            k: Number of top results
            
        Returns:
            (indices, scores) - indices and similarity scores of top-k
        """
        # Compute similarities
        similarities = self.similarity(query_embedding, corpus_embeddings).flatten()
        
        # Get top-k indices
        top_k_indices = np.argsort(similarities)[-k:][::-1]
        top_k_scores = similarities[top_k_indices]
        
        return top_k_indices, top_k_scores
