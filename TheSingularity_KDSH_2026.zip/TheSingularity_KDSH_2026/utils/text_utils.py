"""Text utilities for preprocessing and analysis."""

import re
from typing import List
from collections import Counter


def clean_text(text: str) -> str:
    """Clean and normalize text."""
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def split_into_sentences(text: str) -> List[str]:
    """Split text into sentences."""
    sentences = re.split(r'(?<=[.!?])\s+', text)
    return [s.strip() for s in sentences if s.strip()]


def count_words(text: str) -> int:
    """Count words in text."""
    return len(text.split())


def count_tokens(text: str, words_to_tokens_ratio: float = 1.3) -> int:
    """Estimate token count from word count."""
    return int(count_words(text) * words_to_tokens_ratio)


def truncate_text(text: str, max_length: int = 256, suffix: str = "...") -> str:
    """Truncate text to maximum length."""
    if len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix


def extract_keywords(text: str, num_keywords: int = 10) -> List[str]:
    """Extract keywords from text using word frequency."""
    words = re.findall(r'\b\w+\b', text.lower())
    stop_words = {
        'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
        'of', 'with', 'is', 'was', 'are', 'be', 'been', 'being', 'have', 'has',
        'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should',
    }
    filtered_words = [w for w in words if w not in stop_words and len(w) > 3]
    word_freq = Counter(filtered_words)
    return [w for w, _ in word_freq.most_common(num_keywords)]
