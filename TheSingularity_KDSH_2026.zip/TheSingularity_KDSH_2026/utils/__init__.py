"""
Utility module initialization.
"""
