"""
Evaluation utilities for consistency predictions.
Metrics and analysis for model performance.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
import logging

logger = logging.getLogger(__name__)


class ConsistencyEvaluator:
    """
    Evaluate consistency predictions against ground truth labels.
    """
    
    def __init__(self):
        """Initialize evaluator."""
        self.predictions = []
        self.ground_truth = []
        self.metadata = []
    
    def add_prediction(self, pred_label: int, true_label: int, 
                       sample_id: int, character: str, book: str,
                       confidence: float = None, rationale: str = None):
        """
        Add a single prediction.
        
        Args:
            pred_label: Predicted label (0=contradict, 1=consistent)
            true_label: Ground truth label (0=contradict, 1=consistent)
            sample_id: Sample ID from dataset
            character: Character name
            book: Book name
            confidence: Prediction confidence (0-1)
            rationale: Explanation string
        """
        self.predictions.append(pred_label)
        self.ground_truth.append(true_label)
        
        self.metadata.append({
            'id': sample_id,
            'character': character,
            'book': book,
            'confidence': confidence,
            'rationale': rationale,
            'correct': pred_label == true_label,
        })
    
    def get_metrics(self) -> Dict:
        """
        Compute evaluation metrics.
        
        Returns:
            Dict with accuracy, precision, recall, F1, confusion matrix
        """
        if len(self.predictions) == 0:
            return {
                'samples': 0,
                'accuracy': 0.0,
                'precision': 0.0,
                'recall': 0.0,
                'f1': 0.0,
                'confusion_matrix': None,
            }
        
        preds = np.array(self.predictions)
        truth = np.array(self.ground_truth)
        
        metrics = {
            'samples': len(preds),
            'accuracy': accuracy_score(truth, preds),
            'precision': precision_score(truth, preds, zero_division=0),
            'recall': recall_score(truth, preds, zero_division=0),
            'f1': f1_score(truth, preds, zero_division=0),
            'confusion_matrix': confusion_matrix(truth, preds).tolist(),
        }
        
        # Class-specific metrics (return arrays by setting average=None)
        prec_per_label = precision_score(truth, preds, labels=[0, 1], average=None, zero_division=0)
        rec_per_label = recall_score(truth, preds, labels=[0, 1], average=None, zero_division=0)

        metrics['precision_per_class'] = {
            'contradict': float(prec_per_label[0]),
            'consistent': float(prec_per_label[1]),
        }

        metrics['recall_per_class'] = {
            'contradict': float(rec_per_label[0]),
            'consistent': float(rec_per_label[1]),
        }
        
        return metrics
    
    def get_errors(self) -> pd.DataFrame:
        """
        Get all incorrect predictions.
        
        Returns:
            DataFrame with error details
        """
        if len(self.metadata) == 0:
            return pd.DataFrame()
        
        df = pd.DataFrame(self.metadata)
        errors = df[~df['correct']]
        
        return errors[['id', 'character', 'book', 'confidence', 'rationale']].reset_index(drop=True)
    
    def get_summary(self) -> str:
        """
        Get human-readable summary.
        
        Returns:
            Formatted string with evaluation summary
        """
        metrics = self.get_metrics()
        
        if metrics['samples'] == 0:
            return "No predictions to evaluate."
        
        summary = f"""
=== Consistency Model Evaluation ===
Samples: {metrics['samples']}
Accuracy: {metrics['accuracy']:.2%}
Precision: {metrics['precision']:.2%}
Recall: {metrics['recall']:.2%}
F1 Score: {metrics['f1']:.2%}

Confusion Matrix:
  Predicted:  [Contradict  Consistent]
  Actual
  Contradict: {metrics['confusion_matrix'][0]}
  Consistent: {metrics['confusion_matrix'][1]}

Per-Class Metrics:
  Contradict - Precision: {metrics['precision_per_class']['contradict']:.2%}, Recall: {metrics['recall_per_class']['contradict']:.2%}
  Consistent - Precision: {metrics['precision_per_class']['consistent']:.2%}, Recall: {metrics['recall_per_class']['consistent']:.2%}
"""
        return summary
    
    def get_report(self) -> pd.DataFrame:
        """
        Get detailed report of all predictions.
        
        Returns:
            DataFrame with full prediction details
        """
        return pd.DataFrame(self.metadata)
    
    def save_report(self, filepath: str):
        """
        Save detailed report to CSV.
        
        Args:
            filepath: Output CSV file path
        """
        report = self.get_report()
        report.to_csv(filepath, index=False)
        logger.info(f"Saved evaluation report: {filepath}")
    
    def analyze_by_book(self) -> Dict[str, Dict]:
        """
        Get per-book performance metrics.
        
        Returns:
            Dict mapping book name to metrics
        """
        if len(self.metadata) == 0:
            return {}
        
        df = pd.DataFrame(self.metadata)
        results = {}
        
        for book in df['book'].unique():
            book_data = df[df['book'] == book]
            book_indices = [i for i, m in enumerate(self.metadata) if m['book'] == book]
            pred_labels = np.array(self.predictions)[book_indices]
            truth_labels = np.array(self.ground_truth)[book_indices]
            
            results[book] = {
                'samples': len(book_data),
                'accuracy': accuracy_score(truth_labels, pred_labels),
                'correct': book_data['correct'].sum(),
                'errors': (~book_data['correct']).sum(),
            }
        
        return results
    
    def analyze_by_character(self, top_n: int = 10) -> pd.DataFrame:
        """
        Get per-character performance metrics.
        
        Args:
            top_n: Show top N characters by sample count
            
        Returns:
            DataFrame with character-level metrics
        """
        if len(self.metadata) == 0:
            return pd.DataFrame()
        
        df = pd.DataFrame(self.metadata)
        
        char_stats = []
        for char in df['character'].unique():
            char_data = df[df['character'] == char]
            
            pred_labels = [self.predictions[i] for i, m in enumerate(self.metadata) 
                          if m['character'] == char]
            truth_labels = [self.ground_truth[i] for i, m in enumerate(self.metadata) 
                           if m['character'] == char]
            
            char_stats.append({
                'character': char,
                'samples': len(char_data),
                'correct': char_data['correct'].sum(),
                'accuracy': accuracy_score(truth_labels, pred_labels) if len(truth_labels) > 0 else 0,
            })
        
        result_df = pd.DataFrame(char_stats).sort_values('samples', ascending=False)
        return result_df.head(top_n)
    
    def get_confidence_analysis(self) -> Dict:
        """
        Analyze prediction confidence distribution.
        
        Returns:
            Dict with confidence statistics
        """
        if len(self.metadata) == 0 or not any(m['confidence'] for m in self.metadata):
            return {'message': 'No confidence scores available'}
        
        confidences = [m['confidence'] for m in self.metadata if m['confidence'] is not None]
        correct_conf = [c for i, c in enumerate(confidences) if self.metadata[i]['correct']]
        incorrect_conf = [c for i, c in enumerate(confidences) if not self.metadata[i]['correct']]
        
        return {
            'mean_confidence': np.mean(confidences) if confidences else 0,
            'std_confidence': np.std(confidences) if confidences else 0,
            'mean_correct_confidence': np.mean(correct_conf) if correct_conf else 0,
            'mean_incorrect_confidence': np.mean(incorrect_conf) if incorrect_conf else 0,
            'min_confidence': np.min(confidences) if confidences else 0,
            'max_confidence': np.max(confidences) if confidences else 0,
        }
