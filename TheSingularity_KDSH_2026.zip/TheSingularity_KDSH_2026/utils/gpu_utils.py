"""
GPU Utilities.
Device management and GPU-specific optimizations.
"""

import torch
import logging

logger = logging.getLogger(__name__)

def init_gpu():
    """
    Initialize GPU and set optimal settings.
    Call this at application startup.
    """
    if not torch.cuda.is_available():
        logger.warning("No CUDA device found. Using CPU.")
        return False
    
    # Print GPU info
    device_count = torch.cuda.device_count()
    logger.info(f"Number of GPUs: {device_count}")
    
    for i in range(device_count):
        logger.info(f"GPU {i}: {torch.cuda.get_device_name(i)}")
        logger.info(f"  Memory: {torch.cuda.get_device_properties(i).total_memory / 1e9:.2f} GB")
    
    # Set primary device
    torch.cuda.set_device(0)
    
    # Enable TF32 for faster A100 computation
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    logger.info("TF32 precision enabled for faster computation")
    
    # Set cuDNN to benchmark mode (faster after warmup)
    torch.backends.cudnn.benchmark = True
    logger.info("cuDNN benchmark mode enabled")
    
    return True

def clear_cache():
    """Clear GPU cache to free memory."""
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        logger.info("GPU cache cleared")

def get_gpu_memory_stats():
    """
    Get current GPU memory usage statistics.
    
    Returns:
        Dict with memory stats
    """
    if not torch.cuda.is_available():
        return {"available": False}
    
    stats = {
        "available": True,
        "allocated_gb": torch.cuda.memory_allocated(0) / 1e9,
        "reserved_gb": torch.cuda.memory_reserved(0) / 1e9,
        "total_gb": torch.cuda.get_device_properties(0).total_memory / 1e9,
    }
    
    stats["percent_used"] = (
        stats["allocated_gb"] / stats["total_gb"] * 100
    )
    
    return stats

def log_gpu_memory():
    """Log current GPU memory usage."""
    stats = get_gpu_memory_stats()
    if stats["available"]:
        logger.info(
            f"GPU Memory: {stats['allocated_gb']:.2f}GB allocated, "
            f"{stats['reserved_gb']:.2f}GB reserved, "
            f"{stats['percent_used']:.1f}% used"
        )

def warmup_gpu(num_iterations: int = 100):
    """
    Warm up GPU for more stable inference performance.
    
    Args:
        num_iterations: Number of warmup iterations
    """
    if not torch.cuda.is_available():
        return
    
    logger.info(f"Warming up GPU with {num_iterations} iterations...")
    
    # Create dummy tensors and compute
    for i in range(num_iterations):
        x = torch.randn(100, 100).cuda()
        y = torch.randn(100, 100).cuda()
        _ = torch.matmul(x, y)
    
    torch.cuda.synchronize()
    logger.info("GPU warmup complete")

def set_seed(seed: int = 42):
    """
    Set random seeds for reproducibility.
    
    Args:
        seed: Random seed value
    """
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    logger.info(f"Random seed set to {seed}")
