"""
Dataset Loading and Processing Module.
Utilities for loading and working with the KDSH dataset.
"""

import pandas as pd
import os
from typing import Dict, List, Tuple, Optional
from pathlib import Path

class DatasetLoader:
    """
    Load and manage the KDSH dataset.
    Handles CSV files and narrative texts.
    """
    
    def __init__(self, dataset_dir: str = "./Dataset"):
        """
        Initialize dataset loader.
        
        Args:
            dataset_dir: Path to Dataset folder
        """
        self.dataset_dir = Path(dataset_dir)
        self.train_csv = self.dataset_dir / "train.csv"
        self.test_csv = self.dataset_dir / "test.csv"
        self.books_dir = self.dataset_dir / "Books"
        
        # Load narratives
        self.narratives = self._load_narratives()
        
        # Load CSVs
        self.train_df = None
        self.test_df = None
        
    def _load_narratives(self) -> Dict[str, str]:
        """
        Load full narrative texts from Books folder.
        
        Returns:
            Dict mapping book name to full text
        """
        narratives = {}
        
        if not self.books_dir.exists():
            print(f"[WARNING] Books directory not found: {self.books_dir}")
            return narratives
        
        for txt_file in self.books_dir.glob("*.txt"):
            book_name = txt_file.stem
            with open(txt_file, 'r', encoding='utf-8', errors='ignore') as f:
                text = f.read()
                # Remove Project Gutenberg header/footer
                text = self._clean_gutenberg_text(text)
                narratives[book_name] = text
            print(f"[INFO] Loaded narrative: {book_name} ({len(text)} chars)")
        
        return narratives
    
    def _clean_gutenberg_text(self, text: str) -> str:
        """
        Remove Project Gutenberg header and footer.
        
        Args:
            text: Raw text from Project Gutenberg
            
        Returns:
            Cleaned text
        """
        # Find start marker
        start_marker = "*** START OF THE PROJECT GUTENBERG EBOOK"
        end_marker = "*** END OF THE PROJECT GUTENBERG EBOOK"
        
        start_idx = text.find(start_marker)
        end_idx = text.find(end_marker)
        
        if start_idx != -1:
            text = text[start_idx + len(start_marker):]
        
        if end_idx != -1:
            text = text[:end_idx]
        
        return text.strip()
    
    def load_train_data(self) -> pd.DataFrame:
        """
        Load training dataset.
        
        Returns:
            DataFrame with columns: id, book_name, char, caption, content, label
        """
        if not self.train_csv.exists():
            raise FileNotFoundError(f"Train CSV not found: {self.train_csv}")
        
        self.train_df = pd.read_csv(self.train_csv)
        print(f"[INFO] Loaded train data: {len(self.train_df)} samples")
        return self.train_df
    
    def load_test_data(self) -> pd.DataFrame:
        """
        Load test dataset.
        
        Returns:
            DataFrame with columns: id, book_name, char, caption, content
        """
        if not self.test_csv.exists():
            raise FileNotFoundError(f"Test CSV not found: {self.test_csv}")
        
        self.test_df = pd.read_csv(self.test_csv)
        print(f"[INFO] Loaded test data: {len(self.test_df)} samples")
        return self.test_df
    
    def get_narrative(self, book_name: str) -> str:
        """
        Get full narrative text for a book.
        
        Args:
            book_name: Name of book (keys from self.narratives)
            
        Returns:
            Full narrative text
        """
        # Handle minor name variations
        normalized_name = book_name.strip().lower()
        
        for key, text in self.narratives.items():
            if key.lower() == normalized_name or \
               normalized_name.startswith(key.lower()) or \
               key.lower().startswith(normalized_name):
                return text
        
        # Try exact match with different cases
        if book_name in self.narratives:
            return self.narratives[book_name]
        
        raise ValueError(f"Narrative not found for book: {book_name}")
    
    def get_sample(self, idx: int, is_train: bool = True) -> Dict:
        """
        Get a single sample with its narrative.
        
        Args:
            idx: Index in DataFrame
            is_train: Use train data if True, test if False
            
        Returns:
            Dict with backstory, narrative, label (if available)
        """
        df = self.train_df if is_train else self.test_df
        
        if df is None:
            if is_train:
                df = self.load_train_data()
            else:
                df = self.load_test_data()
        
        row = df.iloc[idx]
        
        # Get backstory from 'content' column
        backstory = row['content']
        
        # Get character name
        char_name = row['char']
        
        # Get book name (handle variations)
        book_name = row['book_name']
        
        # Get full narrative
        narrative = self.get_narrative(book_name)
        
        result = {
            'id': row['id'],
            'book': book_name,
            'character': char_name,
            'backstory': backstory,
            'narrative': narrative,
            'caption': row.get('caption', ''),
        }
        
        if 'label' in row:
            result['label'] = row['label']
            result['is_consistent'] = row['label'] == 'consistent'
        
        return result
    
    def get_statistics(self) -> Dict:
        """
        Get dataset statistics.
        
        Returns:
            Statistics dictionary
        """
        if self.train_df is None:
            self.load_train_data()
        if self.test_df is None:
            self.load_test_data()
        
        stats = {
            'train_samples': len(self.train_df),
            'test_samples': len(self.test_df),
            'books': list(self.narratives.keys()),
            'num_books': len(self.narratives),
            'narrative_sizes': {
                name: len(text) for name, text in self.narratives.items()
            },
        }
        
        if self.train_df is not None:
            label_counts = self.train_df['label'].value_counts()
            stats['train_labels'] = label_counts.to_dict()
            stats['train_consistent'] = label_counts.get('consistent', 0)
            stats['train_contradict'] = label_counts.get('contradict', 0)
        
        return stats
    
    def get_by_book(self, book_name: str, is_train: bool = True) -> pd.DataFrame:
        """
        Get all samples for a specific book.
        
        Args:
            book_name: Book name to filter by
            is_train: Use train data if True
            
        Returns:
            Filtered DataFrame
        """
        df = self.train_df if is_train else self.test_df
        
        if df is None:
            if is_train:
                df = self.load_train_data()
            else:
                df = self.load_test_data()
        
        # Handle case-insensitive matching
        return df[df['book_name'].str.lower() == book_name.lower()]
    
    def get_by_character(self, char_name: str, is_train: bool = True) -> pd.DataFrame:
        """
        Get all samples for a specific character.
        
        Args:
            char_name: Character name to filter by
            is_train: Use train data if True
            
        Returns:
            Filtered DataFrame
        """
        df = self.train_df if is_train else self.test_df
        
        if df is None:
            if is_train:
                df = self.load_train_data()
            else:
                df = self.load_test_data()
        
        return df[df['char'].str.contains(char_name, case=False, na=False)]
    
    def get_consistent_samples(self, num: int = 5) -> List[Dict]:
        """
        Get first N consistent samples with full narratives.
        
        Args:
            num: Number of samples
            
        Returns:
            List of sample dicts
        """
        if self.train_df is None:
            self.load_train_data()
        
        consistent = self.train_df[self.train_df['label'] == 'consistent'].head(num)
        
        samples = []
        for idx, row in consistent.iterrows():
            sample = {
                'id': row['id'],
                'book': row['book_name'],
                'character': row['char'],
                'backstory': row['content'],
                'label': 'consistent',
            }
            try:
                sample['narrative'] = self.get_narrative(row['book_name'])
            except ValueError:
                sample['narrative'] = "[Narrative not found]"
            
            samples.append(sample)
        
        return samples
    
    def get_contradict_samples(self, num: int = 5) -> List[Dict]:
        """
        Get first N contradicting samples with full narratives.
        
        Args:
            num: Number of samples
            
        Returns:
            List of sample dicts
        """
        if self.train_df is None:
            self.load_train_data()
        
        contradict = self.train_df[self.train_df['label'] == 'contradict'].head(num)
        
        samples = []
        for idx, row in contradict.iterrows():
            sample = {
                'id': row['id'],
                'book': row['book_name'],
                'character': row['char'],
                'backstory': row['content'],
                'label': 'contradict',
            }
            try:
                sample['narrative'] = self.get_narrative(row['book_name'])
            except ValueError:
                sample['narrative'] = "[Narrative not found]"
            
            samples.append(sample)
        
        return samples
